require 'test_helper'

class GossipLikeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
