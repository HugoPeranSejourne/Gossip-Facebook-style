require 'test_helper'

class CommentLikeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
